import React from 'react';

const Footer = () => {
  return (
    <footer>
      <p>Copyright © Pike, Pabisz, Ghamdi 2023. All rights reserved.</p>
    </footer>
  );
};

export default Footer;
